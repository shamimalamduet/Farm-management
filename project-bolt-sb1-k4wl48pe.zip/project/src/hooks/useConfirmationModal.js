import { useState, useCallback } from 'react';

// Custom hook for managing a confirmation modal
export const useConfirmationModal = () => {
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [confirmAction, setConfirmAction] = useState(null);
  const [confirmMessage, setConfirmMessage] = useState('');

  const openConfirmModal = useCallback((message, action) => {
    setConfirmMessage(message);
    setConfirmAction(() => action);
    setShowConfirmModal(true);
  }, []);

  const handleConfirm = useCallback(() => {
    if (confirmAction) confirmAction();
    setShowConfirmModal(false);
    setConfirmAction(null);
    setConfirmMessage('');
  }, [confirmAction]);

  const handleCancel = useCallback(() => {
    setShowConfirmModal(false);
    setConfirmAction(null);
    setConfirmMessage('');
  }, []);

  return { showConfirmModal, confirmMessage, openConfirmModal, handleConfirm, handleCancel };
};