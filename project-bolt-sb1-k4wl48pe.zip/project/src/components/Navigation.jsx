import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Calendar, Calculator } from 'lucide-react';
import { getLocalizedMessage } from '../constants/messages';

export const Navigation = ({ lang }) => {
  const location = useLocation();

  const navItems = [
    { path: '/', icon: Home, label: 'manageBatches' },
    { path: '/vaccine', icon: Calendar, label: 'vaccineCalendar' },
    { path: '/ration', icon: Calculator, label: 'rationCalculator' },
  ];

  return (
    <nav className="bg-emerald-700 text-white shadow-sm py-3 px-6">
      <ul className="flex justify-center space-x-6">
        {navItems.map(({ path, icon: Icon, label }) => (
          <li key={path}>
            <Link 
              to={path} 
              className={`py-2 px-4 rounded-md transition-colors duration-200 flex items-center space-x-2 ${
                location.pathname === path 
                  ? 'bg-emerald-500 text-white' 
                  : 'hover:bg-emerald-600'
              }`}
            >
              <Icon size={18} />
              <span>{getLocalizedMessage(lang, label)}</span>
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
};