import { useState, useCallback } from 'react';
import { Toast } from '../components/Toast';

// Custom hook for managing toast notifications
export const useToast = () => {
  const [toast, setToast] = useState(null);

  const showToast = useCallback((message, type = 'success', duration = 3000) => {
    setToast({ message, type });
    setTimeout(() => setToast(null), duration);
  }, []);

  const ToastComponent = toast ? (
    <Toast 
      message={toast.message} 
      type={toast.type} 
      onClose={() => setToast(null)} 
    />
  ) : null;

  return { showToast, ToastComponent };
};