import React, { useState, useCallback } from 'react';
import { format, differenceInDays } from 'date-fns';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { useForm } from '../hooks/useForm';
import { useToast } from '../hooks/useToast';
import { useConfirmationModal } from '../hooks/useConfirmationModal';
import { Table } from '../components/Table';
import { StatCard } from '../components/StatCard';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { ANIMAL_TYPES, ANIMAL_PREFIXES } from '../constants/animalTypes';
import { ANIMAL_BREEDS } from '../constants/animalBreeds';
import { VACCINE_PROTOCOLS } from '../data/vaccineProtocols';
import { getLocalizedMessage } from '../constants/messages';
import { convertToEnglishNumerals, getAnimalTypeLabel, getBreedLabel } from '../utils/helpers';
import { addDays } from 'date-fns';

export const BatchManagement = ({ lang }) => {
  const { showToast, ToastComponent } = useToast();
  const { showConfirmModal, confirmMessage, openConfirmModal, handleConfirm, handleCancel } = useConfirmationModal();

  const [batches, setBatches] = useLocalStorage('batches', []);
  const [editingBatchId, setEditingBatchId] = useState(null);
  const [vaccineSchedules, setVaccineSchedules] = useLocalStorage('vaccineSchedules', []);
  const [feedRecords] = useLocalStorage('feedRecords', {});

  const initialBatchForm = {
    batchName: '',
    animalType: '',
    startDate: format(new Date(), 'yyyy-MM-dd'),
    quantity: '',
    initialCost: '',
    initialAge: '',
    fatherId: '',
    motherId: '',
    breed: '',
    birthWeight: '',
  };

  const { formData: batchFormData, handleChange: handleBatchFormChange, handleNumericInputChange: handleBatchNumericInputChange, handleSubmit: handleBatchFormSubmit, resetForm: resetBatchForm, setFormData: setBatchFormData } = useForm(initialBatchForm, (data) => {
    const numericQuantity = parseFloat(convertToEnglishNumerals(data.quantity));
    const numericInitialCost = parseFloat(convertToEnglishNumerals(data.initialCost));
    const numericInitialAge = parseFloat(convertToEnglishNumerals(data.initialAge));
    const numericBirthWeight = parseFloat(convertToEnglishNumerals(data.birthWeight));

    if (editingBatchId) {
      setBatches(batches.map(batch => 
        batch.id === editingBatchId 
          ? { 
              ...batch, 
              batchName: data.batchName, 
              animalType: data.animalType, 
              startDate: data.startDate, 
              quantity: numericQuantity, 
              initialCost: numericInitialCost, 
              initialAge: numericInitialAge, 
              fatherId: data.fatherId, 
              motherId: data.motherId, 
              breed: data.breed, 
              birthWeight: numericBirthWeight 
            } 
          : batch
      ));
      setEditingBatchId(null);
      showToast('batchUpdated', 'success');
    } else {
      const newId = `${ANIMAL_PREFIXES[data.animalType][lang]}${batches.length + 1}`;
      const newBatch = {
        id: newId,
        batchName: data.batchName,
        animalType: data.animalType,
        startDate: data.startDate,
        quantity: numericQuantity,
        initialCost: numericInitialCost,
        initialAge: numericInitialAge,
        fatherId: data.fatherId,
        motherId: data.motherId,
        breed: data.breed,
        birthWeight: numericBirthWeight,
      };
      setBatches([...batches, newBatch]);

      // Auto-generate vaccine schedules
      const protocolsForAnimalType = VACCINE_PROTOCOLS[data.animalType];
      if (protocolsForAnimalType) {
        const newSchedules = protocolsForAnimalType.map((protocol, index) => {
          const scheduleDate = addDays(new Date(newBatch.startDate), protocol.dayOffset);
          return {
            id: `vaccine-${newId}-${index}-${Date.now()}`,
            batchId: newId,
            vaccineName: protocol.name,
            scheduleDate: format(scheduleDate, 'yyyy-MM-dd'),
            status: 'pending',
          };
        });
        setVaccineSchedules(prevSchedules => [...prevSchedules, ...newSchedules]);
      }
      showToast('batchAdded', 'success');
    }
    resetBatchForm();
  });

  const handleEditBatch = useCallback((batch) => {
    setEditingBatchId(batch.id);
    setBatchFormData({
      ...batch,
      fatherId: batch.fatherId || '',
      motherId: batch.motherId || '',
      breed: batch.breed || '',
      birthWeight: batch.birthWeight || '',
    });
  }, [setBatchFormData]);

  const handleDeleteBatch = useCallback((id) => {
    openConfirmModal(getLocalizedMessage(lang, 'areYouSureDelete'), () => {
      setBatches(batches.filter(batch => batch.id !== id));
      setVaccineSchedules(prev => prev.filter(schedule => schedule.batchId !== id));
      showToast('batchDeleted', 'success');
    });
  }, [batches, setBatches, setVaccineSchedules, showToast, openConfirmModal, lang]);

  // Calculate statistics
  const totalBatches = batches.length;
  const totalAnimals = batches.reduce((sum, batch) => sum + batch.quantity, 0);
  const totalInitialCost = batches.reduce((sum, batch) => sum + batch.initialCost, 0);
  const totalOverallFeedCost = Object.values(feedRecords).flat().reduce((sum, record) => sum + record.feedCost, 0);

  // Get upcoming vaccine reminders
  const upcomingVaccineReminders = vaccineSchedules
    .filter(schedule => 
      schedule.status === 'pending' && 
      differenceInDays(new Date(schedule.scheduleDate), new Date()) >= 0 && 
      differenceInDays(new Date(schedule.scheduleDate), new Date()) <= 7
    )
    .sort((a, b) => new Date(a.scheduleDate) - new Date(b.scheduleDate));

  const pendingVaccinesCount = vaccineSchedules.filter(s => s.status === 'pending').length;
  const completedVaccinesCount = vaccineSchedules.filter(s => s.status === 'completed').length;

  const batchColumns = [
    { header: 'id', key: 'id' },
    { header: 'batchName', key: 'batchName' },
    { header: 'animalType', key: 'animalType', render: (row) => getAnimalTypeLabel(row.animalType, lang, ANIMAL_TYPES) },
    { header: 'breed', key: 'breed', render: (row) => getBreedLabel(row.animalType, row.breed, lang, ANIMAL_BREEDS) },
    { header: 'startDate', key: 'startDate' },
    { header: 'quantity', key: 'quantity' },
    { header: 'initialCost', key: 'initialCost' },
    { 
      header: 'currentAge', 
      key: 'currentAge', 
      render: (row) => {
        const start = new Date(row.startDate);
        const today = new Date();
        const ageInDays = differenceInDays(today, start) + row.initialAge;
        return `${ageInDays.toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')} ${getLocalizedMessage(lang, 'days')}`;
      }
    },
    {
      header: 'actions',
      key: 'actions',
      render: (row) => (
        <div className="flex space-x-2">
          <button
            onClick={() => handleEditBatch(row)}
            className="bg-yellow-500 hover:bg-yellow-600 text-white py-1 px-3 rounded-md text-sm transition duration-300 ease-in-out transform hover:scale-105"
          >
            {getLocalizedMessage(lang, 'edit')}
          </button>
          <button
            onClick={() => handleDeleteBatch(row.id)}
            className="bg-rose-500 hover:bg-rose-600 text-white py-1 px-3 rounded-md text-sm transition duration-300 ease-in-out transform hover:scale-105"
          >
            {getLocalizedMessage(lang, 'delete')}
          </button>
        </div>
      )
    },
  ];

  return (
    <div className="bg-white p-8 rounded-xl shadow-xl max-w-4xl mx-auto">
      {ToastComponent}
      {showConfirmModal && (
        <ConfirmationModal 
          lang={lang} 
          message={confirmMessage} 
          onConfirm={handleConfirm} 
          onCancel={handleCancel} 
        />
      )}

      <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">
        {getLocalizedMessage(lang, 'manageBatches')}
      </h2>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8 text-center">
        <StatCard
          title={getLocalizedMessage(lang, 'totalBatches')}
          value={totalBatches.toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}
          bgColor="bg-blue-100"
          textColor="text-blue-800"
        />
        <StatCard
          title={getLocalizedMessage(lang, 'totalAnimals')}
          value={totalAnimals.toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}
          bgColor="bg-green-100"
          textColor="text-green-800"
        />
        <StatCard
          title={getLocalizedMessage(lang, 'totalInitialCost')}
          value={`${totalInitialCost.toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')} BDT`}
          bgColor="bg-yellow-100"
          textColor="text-yellow-800"
        />
        <StatCard
          title={getLocalizedMessage(lang, 'totalFeedCost')}
          value={`${totalOverallFeedCost.toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')} BDT`}
          bgColor="bg-red-100"
          textColor="text-red-800"
        />
      </div>

      {/* Upcoming Vaccine Reminders */}
      <div className="mb-8">
        <h3 className="text-2xl font-semibold text-gray-800 mb-4">
          {getLocalizedMessage(lang, 'upcomingVaccineReminders')}
        </h3>
        {upcomingVaccineReminders.length > 0 ? (
          <ul className="space-y-2">
            {upcomingVaccineReminders.map(schedule => {
              const batch = batches.find(b => b.id === schedule.batchId);
              return (
                <li key={schedule.id} className="bg-indigo-50 p-3 rounded-lg shadow-sm flex justify-between items-center">
                  <span className="text-lg text-indigo-800">
                    <strong>{format(new Date(schedule.scheduleDate), lang === 'bn' ? 'dd MMMM, yyyy' : 'MMM dd, yyyy')}:</strong> {getLocalizedMessage(lang, schedule.vaccineName)} ({batch?.batchName || 'N/A'})
                  </span>
                  <span className="text-sm text-indigo-600">{getLocalizedMessage(lang, 'pending')}</span>
                </li>
              );
            })}
          </ul>
        ) : (
          <p className="text-gray-600">{getLocalizedMessage(lang, 'noUpcomingReminders')}</p>
        )}
      </div>

      {/* Vaccine Status Summary */}
      <div className="mb-8">
        <h3 className="text-2xl font-semibold text-gray-800 mb-4">
          {getLocalizedMessage(lang, 'vaccineStatusSummary')}
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <StatCard
            title={getLocalizedMessage(lang, 'pendingVaccines')}
            value={pendingVaccinesCount.toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}
            bgColor="bg-amber-100"
            textColor="text-amber-800"
          />
          <StatCard
            title={getLocalizedMessage(lang, 'completedVaccines')}
            value={completedVaccinesCount.toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}
            bgColor="bg-emerald-100"
            textColor="text-emerald-800"
          />
        </div>
      </div>

      {/* Add/Edit Batch Form */}
      <h3 className="text-2xl font-semibold text-gray-800 mb-4 text-center">
        {editingBatchId ? getLocalizedMessage(lang, 'updateBatch') : getLocalizedMessage(lang, 'addNewBatch')}
      </h3>
      
      <form onSubmit={handleBatchFormSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 bg-gray-50 p-6 rounded-lg shadow-inner">
        <div>
          <label htmlFor="batchName" className="block text-sm font-medium text-gray-700 mb-1">
            {getLocalizedMessage(lang, 'batchName')}:
          </label>
          <input
            type="text"
            id="batchName"
            name="batchName"
            value={batchFormData.batchName}
            onChange={handleBatchFormChange}
            required
            className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500"
          />
        </div>

        <div>
          <label htmlFor="animalType" className="block text-sm font-medium text-gray-700 mb-1">
            {getLocalizedMessage(lang, 'animalType')}:
          </label>
          <select
            id="animalType"
            name="animalType"
            value={batchFormData.animalType}
            onChange={handleBatchFormChange}
            required
            className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500 bg-white"
          >
            <option value="">{getLocalizedMessage(lang, 'selectAnimalTypeNutrition')}</option>
            {ANIMAL_TYPES.map(type => (
              <option key={type.value} value={type.value}>
                {type.label[lang]}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="startDate" className="block text-sm font-medium text-gray-700 mb-1">
            {getLocalizedMessage(lang, 'startDate')}:
          </label>
          <input
            type="date"
            id="startDate"
            name="startDate"
            value={batchFormData.startDate}
            onChange={handleBatchFormChange}
            required
            className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500"
          />
        </div>

        <div>
          <label htmlFor="quantity" className="block text-sm font-medium text-gray-700 mb-1">
            {getLocalizedMessage(lang, 'quantity')}:
          </label>
          <input
            type="text"
            id="quantity"
            name="quantity"
            value={batchFormData.quantity}
            onChange={handleBatchNumericInputChange}
            required
            className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500"
          />
        </div>

        <div>
          <label htmlFor="initialCost" className="block text-sm font-medium text-gray-700 mb-1">
            {getLocalizedMessage(lang, 'initialCost')}:
          </label>
          <input
            type="text"
            id="initialCost"
            name="initialCost"
            value={batchFormData.initialCost}
            onChange={handleBatchNumericInputChange}
            required
            className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500"
          />
        </div>

        <div>
          <label htmlFor="initialAge" className="block text-sm font-medium text-gray-700 mb-1">
            {getLocalizedMessage(lang, 'initialAge')}:
          </label>
          <input
            type="text"
            id="initialAge"
            name="initialAge"
            value={batchFormData.initialAge}
            onChange={handleBatchNumericInputChange}
            required
            className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500"
          />
        </div>

        {/* Pedigree Characteristics */}
        <div className="md:col-span-2">
          <h4 className="text-lg font-semibold text-gray-700 mb-3 mt-4">
            {getLocalizedMessage(lang, 'pedigreeCharacteristics')} ({getLocalizedMessage(lang, 'optional')})
          </h4>
        </div>

        <div>
          <label htmlFor="fatherId" className="block text-sm font-medium text-gray-700 mb-1">
            {getLocalizedMessage(lang, 'fatherId')}:
          </label>
          <input
            type="text"
            id="fatherId"
            name="fatherId"
            value={batchFormData.fatherId}
            onChange={handleBatchFormChange}
            className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500"
          />
        </div>

        <div>
          <label htmlFor="motherId" className="block text-sm font-medium text-gray-700 mb-1">
            {getLocalizedMessage(lang, 'motherId')}:
          </label>
          <input
            type="text"
            id="motherId"
            name="motherId"
            value={batchFormData.motherId}
            onChange={handleBatchFormChange}
            className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500"
          />
        </div>

        <div>
          <label htmlFor="breed" className="block text-sm font-medium text-gray-700 mb-1">
            {getLocalizedMessage(lang, 'breed')}:
          </label>
          <select
            id="breed"
            name="breed"
            value={batchFormData.breed}
            onChange={handleBatchFormChange}
            className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500 bg-white"
          >
            <option value="">{getLocalizedMessage(lang, 'selectAnimalTypeNutrition')}</option>
            {batchFormData.animalType && ANIMAL_BREEDS[batchFormData.animalType] && (
              ANIMAL_BREEDS[batchFormData.animalType].map(breed => (
                <option key={breed.value} value={breed.value}>
                  {breed.label[lang]}
                </option>
              ))
            )}
          </select>
        </div>

        <div>
          <label htmlFor="birthWeight" className="block text-sm font-medium text-gray-700 mb-1">
            {getLocalizedMessage(lang, 'birthWeight')}:
          </label>
          <input
            type="text"
            id="birthWeight"
            name="birthWeight"
            value={batchFormData.birthWeight}
            onChange={handleBatchNumericInputChange}
            className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500"
          />
        </div>

        <div className="md:col-span-2 flex justify-center">
          <button
            type="submit"
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-6 rounded-lg shadow-md transition duration-300 ease-in-out transform hover:scale-105"
          >
            {editingBatchId ? getLocalizedMessage(lang, 'updateBatch') : getLocalizedMessage(lang, 'addBatch')}
          </button>
        </div>
      </form>

      {/* Batch List */}
      <h3 className="text-2xl font-semibold text-gray-800 mb-4 text-center">
        {getLocalizedMessage(lang, 'batchList')}
      </h3>
      <Table
        lang={lang}
        columns={batchColumns}
        data={batches}
        emptyMessage={getLocalizedMessage(lang, 'noBatchesYet')}
      />
    </div>
  );
};