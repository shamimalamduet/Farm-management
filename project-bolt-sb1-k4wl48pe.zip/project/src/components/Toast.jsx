import React from 'react';
import { getLocalizedMessage } from '../constants/messages';

// Toast notification component for success/error messages
export const Toast = ({ message, type, onClose }) => {
  const bgColor = type === 'success' ? 'bg-emerald-500' : 'bg-rose-500';
  const title = type === 'success' ? getLocalizedMessage('en', 'success') : getLocalizedMessage('en', 'error');
  
  return (
    <div className={`fixed top-4 right-4 ${bgColor} text-white px-6 py-3 rounded-lg shadow-lg flex items-center space-x-3 z-50 animate-fade-in-down`}>
      <span className="font-bold text-lg">{title}:</span>
      <span className="text-base">{message}</span>
      <button onClick={onClose} className="ml-auto text-white text-xl font-bold">&times;</button>
    </div>
  );
};