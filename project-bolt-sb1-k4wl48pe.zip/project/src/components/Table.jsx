import React from 'react';
import { getLocalizedMessage } from '../constants/messages';

// Reusable Table component
export const Table = ({ lang, columns, data, emptyMessage, footerRows }) => {
  return (
    <div className="overflow-x-auto max-h-96 rounded-xl shadow-xl w-full">
      {data.length === 0 && (!footerRows || footerRows.length === 0) ? (
        <p className="text-gray-600 p-4">{emptyMessage}</p>
      ) : (
        <table className="min-w-full bg-white rounded-xl">
          <thead>
            <tr>
              {columns.map((col, index) => (
                <th key={index} className="py-3 px-4 text-left sticky top-0 bg-emerald-700 text-white z-10 whitespace-nowrap">
                  {getLocalizedMessage(lang, col.header)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((row, rowIndex) => (
              <tr key={row.id || rowIndex} className={`border-b border-gray-200 ${rowIndex % 2 === 0 ? 'bg-white' : 'bg-gray-50'} hover:bg-gray-100 transition-colors duration-200`}>
                {columns.map((col, colIndex) => (
                  <td key={colIndex} className="py-3 px-4 whitespace-nowrap">
                    {col.render ? col.render(row) :
                      (row[col.key] !== undefined && row[col.key] !== null ?
                        (typeof row[col.key] === 'number' ?
                          row[col.key].toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US') :
                          getLocalizedMessage(lang, row[col.key])
                        ) : 'N/A'
                      )
                    }
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
          {footerRows && footerRows.length > 0 && (
            <tfoot>
              {footerRows}
            </tfoot>
          )}
        </table>
      )}
    </div>
  );
};