import React, { useState, useCallback } from 'react';
import { format, addDays, startOfWeek, endOfWeek, startOfMonth, endOfMonth, isSameMonth, isSameDay, addMonths, subMonths } from 'date-fns';
import { enUS, bn } from 'date-fns/locale';
import { ChevronLeft, ChevronRight, ChevronDown, ChevronUp } from 'lucide-react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { useForm } from '../hooks/useForm';
import { useToast } from '../hooks/useToast';
import { useConfirmationModal } from '../hooks/useConfirmationModal';
import { Table } from '../components/Table';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { ANIMAL_TYPES } from '../constants/animalTypes';
import { VACCINE_PROTOCOLS } from '../data/vaccineProtocols';
import { getLocalizedMessage } from '../constants/messages';
import { getAnimalTypeLabel } from '../utils/helpers';

export const VaccineCalendar = ({ lang }) => {
  const { showToast, ToastComponent } = useToast();
  const { showConfirmModal, confirmMessage, openConfirmModal, handleConfirm, handleCancel } = useConfirmationModal();

  const [batches] = useLocalStorage('batches', []);
  const [vaccineSchedules, setVaccineSchedules] = useLocalStorage('vaccineSchedules', []);
  const [editingScheduleId, setEditingScheduleId] = useState(null);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [expandedProtocols, setExpandedProtocols] = useState({});

  const initialVaccineScheduleForm = {
    batchId: '',
    vaccineName: '',
    scheduleDate: format(new Date(), 'yyyy-MM-dd'),
    status: 'pending',
  };

  const { formData: vaccineScheduleFormData, handleChange: handleVaccineScheduleFormChange, handleSubmit: handleVaccineScheduleFormSubmit, resetForm: resetVaccineScheduleForm, setFormData: setVaccineScheduleFormData } = useForm(initialVaccineScheduleForm, (data) => {
    if (editingScheduleId) {
      setVaccineSchedules(vaccineSchedules.map(schedule => 
        schedule.id === editingScheduleId 
          ? { ...schedule, batchId: data.batchId, vaccineName: data.vaccineName, scheduleDate: data.scheduleDate, status: data.status }
          : schedule
      ));
      setEditingScheduleId(null);
      showToast('scheduleUpdated', 'success');
    } else {
      const newId = `vaccine-${vaccineSchedules.length + 1}`;
      setVaccineSchedules([...vaccineSchedules, { id: newId, ...data }]);
      showToast('scheduleAdded', 'success');
    }
    resetVaccineScheduleForm();
  });

  const handleEditVaccineSchedule = useCallback((schedule) => {
    setEditingScheduleId(schedule.id);
    setVaccineScheduleFormData({
      batchId: schedule.batchId,
      vaccineName: schedule.vaccineName,
      scheduleDate: schedule.scheduleDate,
      status: schedule.status,
    });
  }, [setVaccineScheduleFormData]);

  const handleDeleteVaccineSchedule = useCallback((id) => {
    openConfirmModal(getLocalizedMessage(lang, 'areYouSureDelete'), () => {
      setVaccineSchedules(vaccineSchedules.filter(schedule => schedule.id !== id));
      showToast('scheduleDeleted', 'success');
    });
  }, [vaccineSchedules, setVaccineSchedules, showToast, openConfirmModal, lang]);

  const handleMarkComplete = useCallback((id) => {
    setVaccineSchedules(vaccineSchedules.map(schedule => 
      schedule.id === id ? { ...schedule, status: 'completed' } : schedule
    ));
    showToast('scheduleMarkedComplete', 'success');
  }, [vaccineSchedules, setVaccineSchedules, showToast]);

  const toggleProtocolExpansion = useCallback((animalType) => {
    setExpandedProtocols(prev => ({ ...prev, [animalType]: !prev[animalType] }));
  }, []);

  const dateFnsLocale = lang === 'bn' ? bn : enUS;

  const renderHeader = () => {
    const dateFormat = 'MMMM yyyy';
    return (
      <div className="flex justify-between items-center mb-4">
        <button 
          onClick={() => setCurrentMonth(subMonths(currentMonth, 1))} 
          className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors duration-200 flex items-center space-x-2"
        >
          <ChevronLeft size={16} />
          <span>{getLocalizedMessage(lang, 'previousMonth')}</span>
        </button>
        <span className="text-xl font-semibold text-gray-800">
          {format(currentMonth, dateFormat, { locale: dateFnsLocale })}
        </span>
        <button 
          onClick={() => setCurrentMonth(addMonths(currentMonth, 1))} 
          className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors duration-200 flex items-center space-x-2"
        >
          <span>{getLocalizedMessage(lang, 'nextMonth')}</span>
          <ChevronRight size={16} />
        </button>
      </div>
    );
  };

  const renderDays = () => {
    const dateFormat = 'eee';
    const days = [];
    const startDate = startOfWeek(currentMonth, { locale: dateFnsLocale });
    for (let i = 0; i < 7; i++) {
      days.push(
        <div className="text-center font-medium text-gray-600" key={i}>
          {format(addDays(startDate, i), dateFormat, { locale: dateFnsLocale })}
        </div>
      );
    }
    return <div className="grid grid-cols-7 gap-1 mb-2">{days}</div>;
  };

  const renderCells = () => {
    const monthStart = startOfMonth(currentMonth);
    const monthEnd = endOfMonth(monthStart);
    const startDate = startOfWeek(monthStart, { locale: dateFnsLocale });
    const endDate = endOfWeek(monthEnd, { locale: dateFnsLocale });
    const dateFormat = 'd';
    const rows = [];
    let days = [];
    let day = startDate;

    while (day <= endDate) {
      for (let i = 0; i < 7; i++) {
        const formattedDate = format(day, dateFormat, { locale: dateFnsLocale });
        const cloneDay = day;
        const schedulesForDay = vaccineSchedules.filter((schedule) => 
          isSameDay(new Date(schedule.scheduleDate), cloneDay)
        );

        days.push(
          <div 
            className={`p-2 border border-gray-200 rounded-lg h-24 flex flex-col items-center justify-start relative ${
              !isSameMonth(day, monthStart) 
                ? 'bg-gray-100 text-gray-400' 
                : isSameDay(day, new Date()) 
                  ? 'bg-blue-200 text-blue-800 font-bold' 
                  : 'bg-white text-gray-700'
            }`} 
            key={day}
          >
            <span className={`text-sm ${!isSameMonth(day, monthStart) ? 'text-gray-400' : ''}`}>
              {formattedDate}
            </span>
            <div className="flex flex-col items-center justify-center flex-grow overflow-y-auto w-full">
              {schedulesForDay.length > 0 ? (
                schedulesForDay.map((schedule) => (
                  <div 
                    key={schedule.id} 
                    className={`text-xs p-1 rounded-md mt-1 w-full text-center ${
                      schedule.status === 'completed' 
                        ? 'bg-emerald-200 text-emerald-800' 
                        : 'bg-amber-200 text-amber-800'
                    }`}
                  >
                    {getLocalizedMessage(lang, schedule.vaccineName)} ({batches.find(b => b.id === schedule.batchId)?.batchName || 'N/A'})
                  </div>
                ))
              ) : (
                <span className="text-xs text-gray-500">
                  {getLocalizedMessage(lang, 'noVaccinesScheduled')}
                </span>
              )}
            </div>
          </div>
        );
        day = addDays(day, 1);
      }
      rows.push(
        <div className="grid grid-cols-7 gap-1 mb-1" key={day}>
          {days}
        </div>
      );
      days = [];
    }
    return <div>{rows}</div>;
  };

  const scheduleColumns = [
    { 
      header: 'batch', 
      key: 'batchId', 
      render: (row) => batches.find(b => b.id === row.batchId)?.batchName || 'N/A' 
    },
    { 
      header: 'animalType', 
      key: 'animalType', 
      render: (row) => getAnimalTypeLabel(batches.find(b => b.id === row.batchId)?.animalType || '', lang, ANIMAL_TYPES) 
    },
    { 
      header: 'vaccine', 
      key: 'vaccineName', 
      render: (row) => getLocalizedMessage(lang, row.vaccineName) 
    },
    { 
      header: 'date', 
      key: 'scheduleDate', 
      render: (row) => format(new Date(row.scheduleDate), lang === 'bn' ? 'dd MMMM, yyyy' : 'MMM dd, yyyy', { locale: dateFnsLocale }) 
    },
    { 
      header: 'status', 
      key: 'status', 
      render: (row) => (
        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
          row.status === 'completed' 
            ? 'bg-emerald-100 text-emerald-800' 
            : 'bg-amber-100 text-amber-800'
        }`}>
          {getLocalizedMessage(lang, row.status)}
        </span>
      ) 
    },
    {
      header: 'actions',
      key: 'actions',
      render: (row) => (
        <div className="flex space-x-2">
          {row.status === 'pending' && (
            <button
              onClick={() => handleMarkComplete(row.id)}
              className="bg-emerald-500 hover:bg-emerald-600 text-white py-1 px-3 rounded-md text-sm transition duration-300 ease-in-out transform hover:scale-105"
            >
              {getLocalizedMessage(lang, 'markComplete')}
            </button>
          )}
          <button
            onClick={() => handleEditVaccineSchedule(row)}
            className="bg-yellow-500 hover:bg-yellow-600 text-white py-1 px-3 rounded-md text-sm transition duration-300 ease-in-out transform hover:scale-105"
          >
            {getLocalizedMessage(lang, 'edit')}
          </button>
          <button
            onClick={() => handleDeleteVaccineSchedule(row.id)}
            className="bg-rose-500 hover:bg-rose-600 text-white py-1 px-3 rounded-md text-sm transition duration-300 ease-in-out transform hover:scale-105"
          >
            {getLocalizedMessage(lang, 'delete')}
          </button>
        </div>
      )
    },
  ];

  return (
    <div className="bg-white p-8 rounded-xl shadow-xl max-w-4xl mx-auto">
      {ToastComponent}
      {showConfirmModal && (
        <ConfirmationModal 
          lang={lang} 
          message={confirmMessage} 
          onConfirm={handleConfirm} 
          onCancel={handleCancel} 
        />
      )}

      <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">
        {getLocalizedMessage(lang, 'vaccineCalendarTitle')}
      </h2>

      {/* Add/Edit Vaccine Schedule Form */}
      <h3 className="text-2xl font-semibold text-gray-800 mb-4 text-center">
        {editingScheduleId ? getLocalizedMessage(lang, 'updateSchedule') : getLocalizedMessage(lang, 'addVaccineSchedule')}
      </h3>

      <form onSubmit={handleVaccineScheduleFormSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 bg-gray-50 p-6 rounded-lg shadow-inner">
        <div>
          <label htmlFor="batchId" className="block text-sm font-medium text-gray-700 mb-1">
            {getLocalizedMessage(lang, 'selectBatch')}:
          </label>
          <select
            id="batchId"
            name="batchId"
            value={vaccineScheduleFormData.batchId}
            onChange={handleVaccineScheduleFormChange}
            required
            className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500 bg-white"
          >
            <option value="">{getLocalizedMessage(lang, 'selectBatch')}</option>
            {batches.map(batch => (
              <option key={batch.id} value={batch.id}>
                {batch.batchName} ({getAnimalTypeLabel(batch.animalType, lang, ANIMAL_TYPES)})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="vaccineName" className="block text-sm font-medium text-gray-700 mb-1">
            {getLocalizedMessage(lang, 'vaccineName')}:
          </label>
          <select
            id="vaccineName"
            name="vaccineName"
            value={vaccineScheduleFormData.vaccineName}
            onChange={handleVaccineScheduleFormChange}
            required
            className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500 bg-white"
          >
            <option value="">{getLocalizedMessage(lang, 'selectVaccineSchedule')}</option>
            {vaccineScheduleFormData.batchId && 
              VACCINE_PROTOCOLS[batches.find(b => b.id === vaccineScheduleFormData.batchId)?.animalType]?.map(vaccine => (
                <option key={vaccine.name} value={vaccine.name}>
                  {getLocalizedMessage(lang, vaccine.name)} ({getLocalizedMessage(lang, vaccine.type)})
                </option>
              ))
            }
          </select>
        </div>

        <div>
          <label htmlFor="scheduleDate" className="block text-sm font-medium text-gray-700 mb-1">
            {getLocalizedMessage(lang, 'scheduleDate')}:
          </label>
          <input
            type="date"
            id="scheduleDate"
            name="scheduleDate"
            value={vaccineScheduleFormData.scheduleDate}
            onChange={handleVaccineScheduleFormChange}
            required
            className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500"
          />
        </div>

        {editingScheduleId && (
          <div>
            <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-1">
              {getLocalizedMessage(lang, 'status')}:
            </label>
            <select
              id="status"
              name="status"
              value={vaccineScheduleFormData.status}
              onChange={handleVaccineScheduleFormChange}
              className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500 bg-white"
            >
              <option value="pending">{getLocalizedMessage(lang, 'pending')}</option>
              <option value="completed">{getLocalizedMessage(lang, 'completed')}</option>
            </select>
          </div>
        )}

        <div className="md:col-span-2 flex justify-center">
          <button
            type="submit"
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-6 rounded-lg shadow-md transition duration-300 ease-in-out transform hover:scale-105"
          >
            {editingScheduleId ? getLocalizedMessage(lang, 'updateSchedule') : getLocalizedMessage(lang, 'addSchedule')}
          </button>
        </div>
      </form>

      {/* Calendar */}
      <div className="mb-8 p-6 bg-gray-50 rounded-lg shadow-inner">
        {renderHeader()}
        {renderDays()}
        {renderCells()}
      </div>

      {/* Scheduled Vaccines Table */}
      <h3 className="text-2xl font-semibold text-gray-800 mb-4 text-center">
        {getLocalizedMessage(lang, 'scheduledVaccines')}
      </h3>
      <Table
        lang={lang}
        columns={scheduleColumns}
        data={vaccineSchedules}
        emptyMessage={getLocalizedMessage(lang, 'noVaccineData')}
      />

      {/* Ideal Vaccine Schedules */}
      <h3 className="text-2xl font-semibold text-gray-800 mb-4 mt-8 text-center">
        {getLocalizedMessage(lang, 'idealSchedule')}
      </h3>
      {Object.keys(VACCINE_PROTOCOLS).map(animalType => (
        <div key={animalType} className="mb-6 p-4 bg-gray-50 rounded-lg shadow-inner">
          <h4 
            className="text-xl font-semibold text-gray-700 flex justify-between items-center cursor-pointer" 
            onClick={() => toggleProtocolExpansion(animalType)}
          >
            {getAnimalTypeLabel(animalType, lang, ANIMAL_TYPES)} {getLocalizedMessage(lang, 'idealSchedule')}
            {expandedProtocols[animalType] ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
          </h4>
          {expandedProtocols[animalType] && (
            <div className="overflow-x-auto mt-4">
              <table className="min-w-full bg-white rounded-lg shadow-md">
                <thead>
                  <tr>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'vaccineName')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'type')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'dayOffset')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'liveKilled')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'form')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'route')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'duration')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'storage')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'expiry')}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {VACCINE_PROTOCOLS[animalType].map((protocol, index) => (
                    <tr key={index} className="border-b border-gray-200">
                      <td className="py-2 px-3 text-sm">{getLocalizedMessage(lang, protocol.name)}</td>
                      <td className="py-2 px-3 text-sm">{getLocalizedMessage(lang, protocol.type)}</td>
                      <td className="py-2 px-3 text-sm">{protocol.dayOffset.toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                      <td className="py-2 px-3 text-sm">{getLocalizedMessage(lang, protocol.liveKilled)}</td>
                      <td className="py-2 px-3 text-sm">{getLocalizedMessage(lang, protocol.form)}</td>
                      <td className="py-2 px-3 text-sm">{getLocalizedMessage(lang, protocol.route)}</td>
                      <td className="py-2 px-3 text-sm">{getLocalizedMessage(lang, protocol.duration)}</td>
                      <td className="py-2 px-3 text-sm">{protocol.storage}</td>
                      <td className="py-2 px-3 text-sm">{getLocalizedMessage(lang, protocol.expiry)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};