import React from 'react';
import { getLocalizedMessage } from '../constants/messages';

export const Header = ({ lang, toggleLanguage }) => {
  return (
    <header className="bg-emerald-800 text-white shadow-md py-4 px-6 flex flex-col sm:flex-row justify-between items-center">
      <h1 className="text-3xl font-bold mb-3 sm:mb-0">
        {getLocalizedMessage(lang, 'farmManagementApp')}
      </h1>
      <div className="flex items-center space-x-4">
        <span className="text-lg">{getLocalizedMessage(lang, 'language')}:</span>
        <button 
          onClick={toggleLanguage} 
          className="flex items-center justify-center w-8 h-8 rounded-full overflow-hidden border-2 border-emerald-500 ring-2 ring-emerald-300 transition-all duration-200 hover:scale-110"
        >
          <span className="text-xl font-bold text-white">
            {lang === 'bn' ? 'A' : 'অ'}
          </span>
        </button>
      </div>
    </header>
  );
};