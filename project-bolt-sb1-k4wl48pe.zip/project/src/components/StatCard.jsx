import React from 'react';

export const StatCard = ({ title, value, bgColor, textColor }) => {
  return (
    <div className={`${bgColor} p-4 rounded-lg shadow-md`}>
      <h3 className={`text-lg font-semibold ${textColor}`}>{title}</h3>
      <p className={`text-3xl font-bold ${textColor.replace('800', '600')}`}>{value}</p>
    </div>
  );
};