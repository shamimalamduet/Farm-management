import React, { useState, useCallback } from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { BatchManagement } from './pages/BatchManagement';
import { VaccineCalendar } from './pages/VaccineCalendar';
import { RationCalculator } from './pages/RationCalculator';

function App() {
  const [lang, setLang] = useState('bn'); // Default language is Bengali

  const toggleLanguage = useCallback(() => {
    setLang(prevLang => prevLang === 'bn' ? 'en' : 'bn');
  }, []);

  return (
    <Router>
      <div className="min-h-screen bg-gray-100 text-gray-800 flex flex-col" style={{ fontFamily: "'Hind Siliguri', sans-serif" }}>
        <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
        <style>
          {`
          /* Universal box-sizing for consistent layout */
          * {
              margin: 0;
              padding: 0;
              box-sizing: border-box;
              font-family: "Hind Siliguri", sans-serif; /* Apply Hind Siliguri font */
          }

          /* Custom animations */
          @keyframes fade-in-down {
            from {
              opacity: 0;
              transform: translateY(-10px);
            }
            to {
              opacity: 1;
              transform: translateY(0);
            }
          }

          @keyframes scale-in {
            from {
              opacity: 0;
              transform: scale(0.9);
            }
            to {
              opacity: 1;
              transform: scale(1);
            }
          }

          .animate-fade-in-down {
            animation: fade-in-down 0.3s ease-out;
          }

          .animate-scale-in {
            animation: scale-in 0.3s ease-out;
          }
          `}
        </style>

        <Header lang={lang} toggleLanguage={toggleLanguage} />
        <Navigation lang={lang} />
        
        <main className="flex-grow p-6">
          <Routes>
            <Route path="/" element={<BatchManagement lang={lang} />} />
            <Route path="/vaccine" element={<VaccineCalendar lang={lang} />} />
            <Route path="/ration" element={<RationCalculator lang={lang} />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;