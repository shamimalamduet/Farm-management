import React from 'react';
import { getLocalizedMessage } from '../constants/messages';

// Confirmation Modal component
export const ConfirmationModal = ({ lang, message, onConfirm, onCancel }) => {
  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-xl shadow-xl w-full max-w-sm text-center transform scale-100 animate-scale-in">
        <h3 className="text-xl font-semibold text-gray-800 mb-4">
          {getLocalizedMessage(lang, 'confirmDelete')}
        </h3>
        <p className="text-gray-700 mb-6">{message}</p>
        <div className="flex justify-center space-x-4">
          <button 
            onClick={onCancel} 
            className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 ease-in-out transform hover:scale-105"
          >
            {getLocalizedMessage(lang, 'cancel')}
          </button>
          <button 
            onClick={onConfirm} 
            className="bg-rose-600 hover:bg-rose-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 ease-in-out transform hover:scale-105"
          >
            {getLocalizedMessage(lang, 'yesDelete')}
          </button>
        </div>
      </div>
    </div>
  );
};