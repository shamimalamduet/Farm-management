// Function to convert Bengali numerals to English numerals for calculations
export const convertToEnglishNumerals = (input) => {
  if (typeof input !== 'string') return input;
  const bengaliNumerals = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  const englishNumerals = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  return input.split('').map(char => {
    const index = bengaliNumerals.indexOf(char);
    return index !== -1 ? englishNumerals[index] : char;
  }).join('');
};

// Helper function to get animal type label
export const getAnimalTypeLabel = (value, lang, animalTypes) => {
  const animal = animalTypes.find(type => type.value === value);
  return animal ? animal.label[lang] : value;
};

// Helper function to get breed label
export const getBreedLabel = (animalType, breedValue, lang, animalBreeds) => {
  const breeds = animalBreeds[animalType];
  const breed = breeds?.find(b => b.value === breedValue);
  return breed ? breed.label[lang] : breedValue;
};