import React, { useState, useCallback } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { ANIMAL_TYPES, ANIMAL_CATEGORIES, NUTRITION_DATA_MAP } from '../constants/animalTypes';
import { ANIMAL_NUTRITIONAL_NEEDS } from '../data/nutritionalNeeds';
import { FEEDSTUFF_NUTRITION } from '../data/feedstuffNutrition';
import { getLocalizedMessage } from '../constants/messages';
import { convertToEnglishNumerals, getAnimalTypeLabel } from '../utils/helpers';

export const RationCalculator = ({ lang }) => {
  const [selectedAnimalTypeNutrition, setSelectedAnimalTypeNutrition] = useState('');
  const [selectedAnimalCategoryNutrition, setSelectedAnimalCategoryNutrition] = useState('');
  const [animalWeight, setAnimalWeight] = useState('');
  const [selectedFeedstuffs, setSelectedFeedstuffs] = useState([]);
  const [expandedNutritionalTables, setExpandedNutritionalTables] = useState({});

  const handleAnimalTypeNutritionChange = useCallback((e) => {
    setSelectedAnimalTypeNutrition(e.target.value);
    setSelectedAnimalCategoryNutrition('');
    setAnimalWeight('');
    setSelectedFeedstuffs([]);
  }, []);

  const handleAnimalCategoryNutritionChange = useCallback((e) => {
    setSelectedAnimalCategoryNutrition(e.target.value);
    setAnimalWeight('');
    setSelectedFeedstuffs([]);
  }, []);

  const handleAnimalWeightChange = useCallback((e) => {
    const value = convertToEnglishNumerals(e.target.value);
    setAnimalWeight(value);
  }, []);

  const getDailyNutritionalNeeds = useCallback(() => {
    if (!selectedAnimalTypeNutrition || !selectedAnimalCategoryNutrition || !animalWeight) return null;
    const weightNum = parseFloat(convertToEnglishNumerals(animalWeight));
    if (isNaN(weightNum) || weightNum <= 0) return null;

    const mappedAnimalType = NUTRITION_DATA_MAP[selectedAnimalTypeNutrition];
    const animalDataForType = ANIMAL_NUTRITIONAL_NEEDS[mappedAnimalType];
    if (!animalDataForType) return null;

    const relevantCategory = animalDataForType.find(data => data.category === selectedAnimalCategoryNutrition);
    if (!relevantCategory) return null;

    const [minWeight, maxWeight] = relevantCategory.weightRange;
    const averageWeight = (minWeight + maxWeight) / 2;

    let needs = { ...relevantCategory };
    let isExtrapolated = false;

    if (weightNum < minWeight || weightNum > maxWeight) {
      isExtrapolated = true;
      const scalingFactor = weightNum / averageWeight;

      if (relevantCategory.dmBodyWeight && relevantCategory.dmBodyWeight > 0) {
        needs.dm = weightNum * (relevantCategory.dmBodyWeight / 100);
      } else {
        needs.dm = relevantCategory.dm * scalingFactor;
      }

      needs.cp = relevantCategory.cp * scalingFactor;
      needs.tdn = relevantCategory.tdn * scalingFactor;
      needs.cf = relevantCategory.cf * scalingFactor;
      needs.fat = relevantCategory.fat * scalingFactor;
      needs.nem = relevantCategory.nem * scalingFactor;
      needs.neg = relevantCategory.neg * scalingFactor;
      needs.nel = relevantCategory.nel * scalingFactor;
      needs.ca = relevantCategory.ca * scalingFactor;
      needs.p = relevantCategory.p * scalingFactor;
    } else {
      if (relevantCategory.dmBodyWeight && relevantCategory.dmBodyWeight > 0) {
        needs.dm = weightNum * (relevantCategory.dmBodyWeight / 100);
      }
    }

    return { ...needs, isExtrapolated, actualWeight: weightNum };
  }, [selectedAnimalTypeNutrition, selectedAnimalCategoryNutrition, animalWeight]);

  const handleAddFeedstuff = useCallback((feedstuffName) => {
    const existing = selectedFeedstuffs.find(f => f.name === feedstuffName);
    if (!existing) {
      setSelectedFeedstuffs(prev => [...prev, { name: feedstuffName, quantity: 0 }]);
    }
  }, [selectedFeedstuffs]);

  const handleFeedstuffQuantityChange = useCallback((name, value) => {
    const cleanedValue = convertToEnglishNumerals(value).replace(/[^0-9.]/g, '');
    setSelectedFeedstuffs(prev => 
      prev.map(f => (f.name === name ? { ...f, quantity: parseFloat(cleanedValue) || 0 } : f))
    );
  }, []);

  const handleRemoveFeedstuff = useCallback((name) => {
    setSelectedFeedstuffs(prev => prev.filter(f => f.name !== name));
  }, []);

  const calculateFeedstuffTotals = useCallback(() => {
    const totals = { dm: 0, cp: 0, tdn: 0, cf: 0, fat: 0, nem: 0, neg: 0, nel: 0, ca: 0, p: 0 };
    const rows = selectedFeedstuffs.map(selected => {
      const feed = FEEDSTUFF_NUTRITION.find(f => f.name === selected.name);
      if (!feed) return null;

      const quantity = selected.quantity;
      const dm_val = quantity * feed.dm;
      const cp_val = dm_val * feed.cp;
      const tdn_val = dm_val * feed.tdn;
      const cf_val = dm_val * feed.cf;
      const fat_val = dm_val * feed.fat;
      const nem_val = dm_val * feed.nem;
      const neg_val = dm_val * feed.neg;
      const nel_val = dm_val * feed.nel;
      const ca_val = dm_val * feed.ca;
      const p_val = dm_val * feed.p;

      totals.dm += dm_val;
      totals.cp += cp_val;
      totals.tdn += tdn_val;
      totals.cf += cf_val;
      totals.fat += fat_val;
      totals.nem += nem_val;
      totals.neg += neg_val;
      totals.nel += nel_val;
      totals.ca += ca_val;
      totals.p += p_val;

      return {
        name: selected.name,
        label: feed.label,
        quantity: quantity,
        dm: dm_val,
        cp: cp_val,
        tdn: tdn_val,
        cf: cf_val,
        fat: fat_val,
        nem: nem_val,
        neg: neg_val,
        nel: nel_val,
        ca: ca_val,
        p: p_val,
      };
    }).filter(Boolean);
    return { rows, totals };
  }, [selectedFeedstuffs]);

  const toggleNutritionalTableExpansion = useCallback((animalType) => {
    setExpandedNutritionalTables(prev => ({ ...prev, [animalType]: !prev[animalType] }));
  }, []);

  const { rows: feedstuffRows, totals: feedstuffTotals } = calculateFeedstuffTotals();
  const dailyNeeds = getDailyNutritionalNeeds();
  const filteredFeedstuffs = dailyNeeds ? FEEDSTUFF_NUTRITION.filter(feed => feed.category === dailyNeeds.diet) : [];

  return (
    <div className="bg-white p-8 rounded-xl shadow-xl max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">
        {getLocalizedMessage(lang, 'rationCalculatorTitle')}
      </h2>

      {/* Animal Selection Form */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 bg-gray-50 p-6 rounded-lg shadow-inner">
        <div>
          <label htmlFor="animalTypeNutrition" className="block text-sm font-medium text-gray-700 mb-1">
            {getLocalizedMessage(lang, 'animalTypeNutrition')}:
          </label>
          <select
            id="animalTypeNutrition"
            name="animalTypeNutrition"
            value={selectedAnimalTypeNutrition}
            onChange={handleAnimalTypeNutritionChange}
            className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500 bg-white"
          >
            <option value="">{getLocalizedMessage(lang, 'selectAnimalTypeNutrition')}</option>
            {ANIMAL_TYPES.map(type => (
              <option key={type.value} value={type.value}>
                {type.label[lang]}
              </option>
            ))}
          </select>
        </div>

        {selectedAnimalTypeNutrition && ANIMAL_NUTRITIONAL_NEEDS[NUTRITION_DATA_MAP[selectedAnimalTypeNutrition]] && (
          <div>
            <label htmlFor="animalCategoryNutrition" className="block text-sm font-medium text-gray-700 mb-1">
              {getLocalizedMessage(lang, 'animalTypeAgeCondition')}:
            </label>
            <select
              id="animalCategoryNutrition"
              name="animalCategoryNutrition"
              value={selectedAnimalCategoryNutrition}
              onChange={handleAnimalCategoryNutritionChange}
              className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500 bg-white"
            >
              <option value="">{getLocalizedMessage(lang, 'selectAnimalTypeNutrition')}</option>
              {ANIMAL_NUTRITIONAL_NEEDS[NUTRITION_DATA_MAP[selectedAnimalTypeNutrition]].map(category => (
                <option key={category.category} value={category.category}>
                  {category.label[lang]}
                </option>
              ))}
            </select>
          </div>
        )}

        {selectedAnimalCategoryNutrition && (
          <div>
            <label htmlFor="animalWeight" className="block text-sm font-medium text-gray-700 mb-1">
              {getLocalizedMessage(lang, 'weight')} ({getLocalizedMessage(lang, 'kgShort')}):
            </label>
            <input
              type="text"
              id="animalWeight"
              name="animalWeight"
              value={animalWeight}
              onChange={handleAnimalWeightChange}
              className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>
        )}
      </div>

      {/* Daily Nutritional Needs Display */}
      {dailyNeeds ? (
        <div className="mb-8 p-6 bg-emerald-50 rounded-lg shadow-inner">
          <h3 className="text-xl font-semibold text-emerald-800 mb-4">
            {getLocalizedMessage(lang, 'dailyNutritionalNeeds')}
          </h3>
          {dailyNeeds.isExtrapolated && (
            <p className="text-amber-700 bg-amber-100 p-3 rounded-lg mb-4">
              {getLocalizedMessage(lang, 'extrapolatedWarning')}
            </p>
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="bg-emerald-100 p-3 rounded-md">
              <strong className="text-emerald-700">{getLocalizedMessage(lang, 'protein')}:</strong> {(dailyNeeds.cp * 1000).toFixed(2).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')} {getLocalizedMessage(lang, 'gramShort')}
            </div>
            <div className="bg-emerald-100 p-3 rounded-md">
              <strong className="text-emerald-700">{getLocalizedMessage(lang, 'energy')}:</strong> {(dailyNeeds.tdn * 1000).toFixed(2).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')} {getLocalizedMessage(lang, 'gramShort')} (TDN)
            </div>
            <div className="bg-emerald-100 p-3 rounded-md">
              <strong className="text-emerald-700">{getLocalizedMessage(lang, 'fiber')}:</strong> {(dailyNeeds.cf * 1000).toFixed(2).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')} {getLocalizedMessage(lang, 'gramShort')}
            </div>
            <div className="bg-emerald-100 p-3 rounded-md">
              <strong className="text-emerald-700">{getLocalizedMessage(lang, 'calcium')}:</strong> {(dailyNeeds.ca * 1000).toFixed(2).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')} {getLocalizedMessage(lang, 'gramShort')}
            </div>
            <div className="bg-emerald-100 p-3 rounded-md">
              <strong className="text-emerald-700">{getLocalizedMessage(lang, 'phosphorus')}:</strong> {(dailyNeeds.p * 1000).toFixed(2).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')} {getLocalizedMessage(lang, 'gramShort')}
            </div>
            {dailyNeeds.water && (
              <div className="bg-emerald-100 p-3 rounded-md">
                <strong className="text-emerald-700">Water:</strong> {dailyNeeds.water} Liters
              </div>
            )}
            {dailyNeeds.mineralsAndVitamins && (
              <div className="bg-emerald-100 p-3 rounded-md">
                <strong className="text-emerald-700">Minerals & Vitamins:</strong> {dailyNeeds.mineralsAndVitamins[lang]}
              </div>
            )}
          </div>
        </div>
      ) : (
        <p className="text-gray-600 p-4 bg-gray-50 rounded-lg shadow-inner">
          {getLocalizedMessage(lang, 'selectAnimalTypeAndWeight')}
        </p>
      )}

      {/* Feedstuff Selection */}
      {dailyNeeds && (
        <div className="mb-8 p-6 bg-gray-50 rounded-lg shadow-inner">
          <h3 className="text-xl font-semibold text-gray-800 mb-4">
            {getLocalizedMessage(lang, 'selectFeedstuffs')}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="feedstuffSelect" className="block text-sm font-medium text-gray-700 mb-1">
                {getLocalizedMessage(lang, 'feedstuffNutritionList')}:
              </label>
              <select
                id="feedstuffSelect"
                onChange={(e) => handleAddFeedstuff(e.target.value)}
                value=""
                className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500 bg-white"
              >
                <option value="">{getLocalizedMessage(lang, 'selectFeedstuffs')}</option>
                {filteredFeedstuffs.map(feed => (
                  <option key={feed.name} value={feed.name}>
                    {feed.label[lang]}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Feedstuff Results Table */}
          {selectedFeedstuffs.length > 0 && (
            <div className="mt-6 overflow-x-auto">
              <h4 className="text-lg font-semibold text-gray-700 mb-3">
                {getLocalizedMessage(lang, 'feedstuffListAndResults')}
              </h4>
              <table className="min-w-full bg-white rounded-lg shadow-md">
                <thead>
                  <tr>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'name')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'feedstuffQuantity')} ({getLocalizedMessage(lang, 'kgShort')})
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'dm')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'cp')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'tdn')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'cf')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'fat')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'ca')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'p')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'action')}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {feedstuffRows.map((row, index) => (
                    <tr key={index} className="border-b border-gray-200">
                      <td className="py-2 px-3 text-sm">{row.label[lang]}</td>
                      <td className="py-2 px-3 text-sm">
                        <input
                          type="text"
                          value={row.quantity}
                          onChange={(e) => handleFeedstuffQuantityChange(row.name, e.target.value)}
                          className="w-20 p-1 border rounded-md"
                        />
                      </td>
                      <td className="py-2 px-3 text-sm">{row.dm.toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                      <td className="py-2 px-3 text-sm">{row.cp.toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                      <td className="py-2 px-3 text-sm">{row.tdn.toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                      <td className="py-2 px-3 text-sm">{row.cf.toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                      <td className="py-2 px-3 text-sm">{row.fat.toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                      <td className="py-2 px-3 text-sm">{row.ca.toFixed(4).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                      <td className="py-2 px-3 text-sm">{row.p.toFixed(4).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                      <td className="py-2 px-3 text-sm">
                        <button
                          onClick={() => handleRemoveFeedstuff(row.name)}
                          className="bg-rose-500 hover:bg-rose-600 text-white py-1 px-2 rounded-md text-xs"
                        >
                          Remove
                        </button>
                      </td>
                    </tr>
                  ))}
                  
                  {/* Totals Row */}
                  <tr className="bg-gray-100 font-semibold">
                    <td className="py-2 px-3 text-sm">{getLocalizedMessage(lang, 'total')}</td>
                    <td className="py-2 px-3 text-sm"></td>
                    <td className="py-2 px-3 text-sm">{feedstuffTotals.dm.toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                    <td className="py-2 px-3 text-sm">{feedstuffTotals.cp.toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                    <td className="py-2 px-3 text-sm">{feedstuffTotals.tdn.toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                    <td className="py-2 px-3 text-sm">{feedstuffTotals.cf.toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                    <td className="py-2 px-3 text-sm">{feedstuffTotals.fat.toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                    <td className="py-2 px-3 text-sm">{feedstuffTotals.ca.toFixed(4).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                    <td className="py-2 px-3 text-sm">{feedstuffTotals.p.toFixed(4).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                    <td className="py-2 px-3 text-sm"></td>
                  </tr>

                  {/* Required Row */}
                  {dailyNeeds && (
                    <>
                      <tr className="bg-blue-50 font-semibold">
                        <td colSpan="2" className="py-2 px-3 text-sm">{getLocalizedMessage(lang, 'required')}</td>
                        <td className="py-2 px-3 text-sm">{dailyNeeds.dm.toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                        <td className="py-2 px-3 text-sm">{dailyNeeds.cp.toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                        <td className="py-2 px-3 text-sm">{dailyNeeds.tdn.toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                        <td className="py-2 px-3 text-sm">{dailyNeeds.cf.toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                        <td className="py-2 px-3 text-sm">{dailyNeeds.fat.toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                        <td className="py-2 px-3 text-sm">{dailyNeeds.ca.toFixed(4).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                        <td className="py-2 px-3 text-sm">{dailyNeeds.p.toFixed(4).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                        <td className="py-2 px-3 text-sm"></td>
                      </tr>

                      {/* Deficit/Surplus Row */}
                      <tr className="bg-yellow-50 font-semibold">
                        <td colSpan="2" className="py-2 px-3 text-sm">{getLocalizedMessage(lang, 'deficitSurplus')}</td>
                        <td className="py-2 px-3 text-sm">{(feedstuffTotals.dm - dailyNeeds.dm).toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                        <td className="py-2 px-3 text-sm">{(feedstuffTotals.cp - dailyNeeds.cp).toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                        <td className="py-2 px-3 text-sm">{(feedstuffTotals.tdn - dailyNeeds.tdn).toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                        <td className="py-2 px-3 text-sm">{(feedstuffTotals.cf - dailyNeeds.cf).toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                        <td className="py-2 px-3 text-sm">{(feedstuffTotals.fat - dailyNeeds.fat).toFixed(3).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                        <td className="py-2 px-3 text-sm">{(feedstuffTotals.ca - dailyNeeds.ca).toFixed(4).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                        <td className="py-2 px-3 text-sm">{(feedstuffTotals.p - dailyNeeds.p).toFixed(4).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                        <td className="py-2 px-3 text-sm"></td>
                      </tr>
                    </>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Nutritional Tables by Animal Type */}
      <h3 className="text-2xl font-semibold text-gray-800 mb-4 mt-8 text-center">
        {getLocalizedMessage(lang, 'animalNutritionalNeedsByWeight')}
      </h3>
      {Object.keys(ANIMAL_NUTRITIONAL_NEEDS).map(animalType => (
        <div key={animalType} className="mb-6 p-4 bg-gray-50 rounded-lg shadow-inner">
          <h4 
            className="text-xl font-semibold text-gray-700 flex justify-between items-center cursor-pointer" 
            onClick={() => toggleNutritionalTableExpansion(animalType)}
          >
            {getAnimalTypeLabel(animalType, lang, ANIMAL_TYPES)} {getLocalizedMessage(lang, ANIMAL_CATEGORIES[animalType])}
            {expandedNutritionalTables[animalType] ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
          </h4>
          {expandedNutritionalTables[animalType] && (
            <div className="overflow-x-auto mt-4">
              <table className="min-w-full bg-white rounded-lg shadow-md">
                <thead>
                  <tr>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'animalTypeAgeCondition')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'weightRange')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'productionType')}
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'dm')} ({getLocalizedMessage(lang, 'kgShort')})
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'protein')} (%)
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'energy')} (TDN %)
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'fiber')} (%)
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'calcium')} (%)
                    </th>
                    <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                      {getLocalizedMessage(lang, 'phosphorusP')}
                    </th>
                    {animalType === 'cow' && (
                      <>
                        <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                          Water (Liters)
                        </th>
                        <th className="py-2 px-3 text-left text-sm font-medium text-gray-700 bg-gray-200">
                          Minerals & Vitamins
                        </th>
                      </>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {ANIMAL_NUTRITIONAL_NEEDS[animalType].map((data, index) => (
                    <tr key={index} className="border-b border-gray-200">
                      <td className="py-2 px-3 text-sm">{data.label[lang]}</td>
                      <td className="py-2 px-3 text-sm">
                        {data.weightRange[0].toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}-{data.weightRange[1].toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')} {getLocalizedMessage(lang, 'kgShort')}
                      </td>
                      <td className="py-2 px-3 text-sm">
                        {data.productionType ? data.productionType[lang] : 'N/A'}
                      </td>
                      <td className="py-2 px-3 text-sm">
                        {data.dmBodyWeight 
                          ? `${data.dmBodyWeight.toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}% (${getLocalizedMessage(lang, 'dmBodyWeight')})` 
                          : `${data.dm.toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}`
                        }
                      </td>
                      <td className="py-2 px-3 text-sm">{(data.cp * 100).toFixed(2).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                      <td className="py-2 px-3 text-sm">{(data.tdn * 100).toFixed(2).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                      <td className="py-2 px-3 text-sm">{(data.cf * 100).toFixed(2).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                      <td className="py-2 px-3 text-sm">{(data.ca * 100).toFixed(2).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                      <td className="py-2 px-3 text-sm">{(data.p * 100).toFixed(2).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US')}</td>
                      {animalType === 'cow' && (
                        <>
                          <td className="py-2 px-3 text-sm">{data.water}</td>
                          <td className="py-2 px-3 text-sm">{data.mineralsAndVitamins[lang]}</td>
                        </>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};