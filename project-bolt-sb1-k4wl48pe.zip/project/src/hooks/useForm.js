import { useState, useCallback } from 'react';
import { convertToEnglishNumerals } from '../utils/helpers';

// Custom hook for managing form state and submission
export const useForm = (initialState, onSubmitCallback) => {
  const [formData, setFormData] = useState(initialState);

  const handleChange = useCallback((e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  }, []);

  const handleNumericInputChange = useCallback((e) => {
    const { name, value } = e.target;
    // Allow digits, decimal point, and Bengali numerals
    const cleanedValue = value.replace(/[^0-9.\u09E6-\u09EF]/g, '');
    const parts = cleanedValue.split('.');
    const finalValue = parts.length > 2 ? parts[0] + '.' + parts.slice(1).join('') : cleanedValue;
    setFormData(prev => ({ ...prev, [name]: finalValue }));
  }, []);

  const handleSubmit = useCallback((e) => {
    e.preventDefault();
    onSubmitCallback(formData);
  }, [formData, onSubmitCallback]);

  const resetForm = useCallback(() => setFormData(initialState), [initialState]);

  return { formData, handleChange, handleNumericInputChange, handleSubmit, resetForm, setFormData };
};